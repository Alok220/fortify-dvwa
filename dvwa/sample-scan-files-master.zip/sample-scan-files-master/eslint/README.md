-ESLint-

Bandit is a pluggable JavaScript linter, including many security plugins (see this [post](https://securityguide.github.io/webapps/tools/javascript-tools/javascript-static-analysis.html) for some examples)

Github: https://github.com/eslint/eslint
