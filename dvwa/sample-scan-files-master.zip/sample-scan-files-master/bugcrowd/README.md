-BugCrowd-

BugCrowd is a 'Crowsourced Cybyersecurity Platform'

The sample file is a CSV export from their bug bounty platform.

Site: https://www.bugcrowd.com/
