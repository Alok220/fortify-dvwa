-VCG-

VCG is an automated code security review tool that handles C/C++, Java, C#, VB and PL/SQL. It has a few features that should hopefully make it useful to anyone conducting code security reviews, particularly where time is at a premium.

-NO SAMPLE SCAN FILES ARE AVAILABLE AT THIS TIME-

Github: https://github.com/nccgroup/VCG
