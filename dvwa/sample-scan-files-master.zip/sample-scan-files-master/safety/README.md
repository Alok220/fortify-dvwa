-Safety Scan-

Microsoft Safety Scanner is a scan tool designed to find and remove malware from Windows computers. Simply download it and run a scan to find malware and try to reverse changes made by identified threats.

Website: https://docs.microsoft.com/en-us/windows/security/threat-protection/intelligence/safety-scanner-download
Github: https://github.com/MicrosoftDocs/windows-itpro-docs/blob/master/windows/security/threat-protection/intelligence/safety-scanner-download.md
