# Risk Recon API

API importer that queries all findings in a Risk Recon Instance. The query can be filtered by supplying accepted limiters. 

Website: https://www.riskrecon.com
Report Configuration: https://defectdojo.readthedocs.io/en/latest/integrations.html#risk-recon-api-importer