-Generic-

Generic uses a csv file with columns corresponding to findings and their data.
