-SSL Labs-

SSL Labs is a collection of documents, tools and thoughts related to SSL. It's an attempt to better understand how SSL is deployed, and an attempt to make it better.

Some failing scans were generated from [badssl.com](https://badssl.com/).

Website: https://www.ssllabs.com/
