-Kiuwan-

Automatically scan your code to identify and remediate vulnerabilities. Compliant with the most stringent security standards, such as OWASP and CWE, Kiuwan Code Security covers all important languages and integrates with leading DevOps tools.

Website: https://www.kiuwan.com/code-security-sast/
