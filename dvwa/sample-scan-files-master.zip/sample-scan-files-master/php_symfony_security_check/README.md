-PHP Symfony Security Check-

Symfony is a set of PHP Components, a Web Application framework, a Philosophy, and a Community — all working together in harmony.

Website: https://symfony.com/what-is-symfony
Github: https://github.com/sensiolabs/security-checker
