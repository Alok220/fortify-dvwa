-Whitesource-

WhiteSource manages open source license compliance and security unlike any other solution on the market.
It integrates fully into your build process, no matter your programming languages, build tools, or development environments. 

Website: https://www.whitesourcesoftware.com/
