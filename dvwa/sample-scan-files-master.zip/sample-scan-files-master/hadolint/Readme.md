-Hadolint-

Automatically scan your Dockefile to identify and remediate vulnerabilities/bugs. 

Github: https://github.com/hadolint/hadolint
