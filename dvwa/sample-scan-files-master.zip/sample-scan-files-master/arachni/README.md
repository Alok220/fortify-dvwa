-Arachni-

Arachni is a feature-full, modular, high-performance Ruby framework aimed towards helping penetration testers and administrators evaluate the security of modern web applications.

Website: https://www.arachni-scanner.com/
Github: https://github.com/Arachni/arachni 
