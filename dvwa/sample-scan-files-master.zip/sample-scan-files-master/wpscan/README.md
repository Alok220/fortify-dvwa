-Wpscan-

WPScan is a free, for non-commercial use, black box WordPress vulnerability scanner written for security professionals and blog maintainers to test the security of their sites.

Website: https://wpscan.org/
Github: https://github.com/wpscanteam/wpscan
