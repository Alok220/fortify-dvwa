-Qualys Webapp-

WAS finds and catalogs all web apps in your network, including new and unknown ones, and scales from a handful of apps to thousands. With Qualys WAS, you can tag your applications with your own labels and then use those labels to control reporting and limit access to scan data.

Note: Dates on the sample files represent when they were generated.  It appears that Qualys recently changed the XML format used in their exported reports and the older XML sytnax is called "Legacy Format" by Quays WAS as of April 2020.

Website: https://www.qualys.com/apps/web-app-scanning/
