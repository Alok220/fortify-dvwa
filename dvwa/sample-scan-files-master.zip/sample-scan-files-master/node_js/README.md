Node JS
=======

A tool used to run static analysis on javascript files

https://github.com/ajinabraham/NodeJsScan