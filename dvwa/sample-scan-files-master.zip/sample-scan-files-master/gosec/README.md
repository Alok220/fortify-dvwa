-Gosec-

Inspects source code for security problems by scanning the Go AST.

Github: https://github.com/securego/gosec
