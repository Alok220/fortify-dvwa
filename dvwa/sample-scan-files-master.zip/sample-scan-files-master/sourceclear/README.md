-Sourceclear-

Fast and easy deployment to your development pipeline, instant visibility into your open-source consumption. Define policies and automate actions. Take back control of your software supply chain.

Website: https://www.sourceclear.com/
Github: https://github.com/srcclr/efda-webscanner
