-Snyk-

Snyk continuously monitors your application's dependencies
and lets you quickly respond when new vulnerabilities are disclosed

Website: https://snyk.io/product/
Github: https://github.com/snyk
