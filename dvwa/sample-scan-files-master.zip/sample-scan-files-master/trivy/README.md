-Trivy-

A Simple and Comprehensive Vulnerability Scanner for Containers, Suitable for CI (https://github.com/aquasecurity/trivy)
