-NPM Audit-

Scan your project for vulnerabilities and automatically install any compatible updates to vulnerable dependencies

Website: https://docs.npmjs.com/cli/audit
Github: https://github.com/npm/npm-audit-report
