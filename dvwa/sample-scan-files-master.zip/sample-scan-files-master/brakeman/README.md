-Brakeman-

Brakeman is a free vulnerability scanner specifically designed for Ruby on Rails applications. It statically analyzes Rails application code to find security issues at any stage of development.

Website: https://brakemanscanner.org/
Github: https://github.com/presidentbeef/brakeman
