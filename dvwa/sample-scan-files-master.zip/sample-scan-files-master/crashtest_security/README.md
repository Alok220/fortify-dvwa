-Crashtest Security-

The Crashtest Security Suite fits the needs of agile development teams programming web applications and APIs. With the black-box approach it checks for common web app vulnerabilities, e.g. the OWASP Top 10.

Website: https://crashtest-security.com/product
Github: https://github.com/crashtest-security/gist
