-Skf-

SKF (Security knowledge framework) is an OWASP tool that is used as a guide for building and verifying secure software. It can also be used to train developers about application security.

-NO SAMPLE SCAN FILES ARE AVAILABLE AT THIS TIME-

Website: https://medium.com/@priyankajain997/installing-security-knowledge-framework-skf-233f08a6c1ff
Github: https://github.com/blabla1337/skf-flask
