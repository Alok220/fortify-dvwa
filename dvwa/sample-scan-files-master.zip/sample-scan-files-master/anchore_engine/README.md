-Anchore Engine-

The Anchore Engine is an open source project that provides a centralized service for performing detailed analysis on container images, running queries, producing reports and defining policies that can be used in CI/CD pipelines.

Website: https://anchore.com/engine/
Github: https://github.com/anchore/anchore-engine
