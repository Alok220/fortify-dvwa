-Retire.js-

Scanner detecting the use of JavaScript libraries with known vulnerabilities 

Website: https://retirejs.github.io/retire.js/
Github: https://github.com/retirejs/retire.js/
