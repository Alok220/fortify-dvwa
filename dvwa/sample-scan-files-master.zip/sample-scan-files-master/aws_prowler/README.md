-AWS Prowler-

Prowler is a command line tool for AWS Security Best Practices Assessment, Auditing, Hardening and Forensics Readiness Tool.
It follows guidelines of the CIS Amazon Web Services Foundations Benchmark (49 checks) and has 40 additional checks including related to GDPR and HIPAA.

Website: https://blog.savagesec.com/securing-your-aws-infrastructure-using-prowler-ec6e6b97513
Github: https://github.com/toniblyx/prowler
