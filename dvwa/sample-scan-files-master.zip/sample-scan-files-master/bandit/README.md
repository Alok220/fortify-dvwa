-Bandit-

Bandit is a tool designed to find common security issues in Python code. 

Github: https://github.com/PyCQA/bandit
