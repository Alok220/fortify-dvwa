-SSL Scan-

This free online service performs a deep analysis of the configuration of any SSL web server on the public Internet.

Website: https://www.ssllabs.com/ssltest/
Github: https://github.com/rbsec/sslscan
