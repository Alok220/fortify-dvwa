-Wapiti-

Wapiti allows you to audit the security of your websites or web applications.

Website: http://wapiti.sourceforge.net/
Github: https://github.com/IFGHou/wapiti
