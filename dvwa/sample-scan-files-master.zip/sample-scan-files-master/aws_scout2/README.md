AWS Scout2 is no longer under development. The latest (and final) version of Scout2 can be found in https://github.com/nccgroup/Scout2/releases and https://pypi.org/project/AWSScout2.

The project has migrated to https://github.com/nccgroup/ScoutSuite.
