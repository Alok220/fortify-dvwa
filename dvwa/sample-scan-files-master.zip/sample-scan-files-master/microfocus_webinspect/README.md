-Microfocus Webinspect-

Micro Focus WebInspect is an automated dynamic testing solution that discovers configuration issues, and identifies and prioritizes security vulnerabilities in running applications. It mimics real-world hacking techniques and provides comprehensive dynamic analysis of complex web applications and services. WebInspect dashboards and reports provide organizations with visibility and an accurate risk posture of your applications.

Website: https://www.microfocus.com/en-us/products/webinspect-dynamic-analysis-dast/how-it-works
