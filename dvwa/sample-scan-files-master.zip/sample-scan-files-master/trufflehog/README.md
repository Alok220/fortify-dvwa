-Trufflehog-

Searches through git repositories for high entropy strings and secrets, digging deep into commit history 

Github: https://github.com/dxa4481/truffleHog
