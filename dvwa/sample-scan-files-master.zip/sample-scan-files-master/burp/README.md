-Burp-

Burp includes coverage of over 100 generic vulnerabilities, such as SQL injection and cross-site scripting (XSS), with great performance against all vulnerabilities in the OWASP top 10.

Export from Burpsuite as XML. When the Burp report is generated, the recommended option is Base64 encoding both the request and response fields - e.g. check the box that says "Base64-encode requests and responses". These fields will be processed and made available in the 'Finding View' page.

Website: https://portswigger.net/burp
