-Nikto-

Nikto is an Open Source (GPL) web server scanner which performs comprehensive tests against web servers for multiple items, including over 6700 potentially dangerous files/programs, checks for outdated versions of over 1250 servers, and version specific problems on over 270 servers.

Website: https://cirt.net/Nikto2
Github: https://github.com/sullo/nikto
