-Nexpose-

Nexpose, Rapid7’s on-premise option for vulnerability management software, monitors exposures in real-time and adapts to new threats with fresh data, ensuring you can always act at the moment of impact.

Website: https://www.rapid7.com/products/nexpose/
Github: https://github.com/rapid7/nexpose-client/releases/tag/v7.2.1
