-Dawnscanner-

Dawnscanner is a source code scanner designed to review your ruby code for security issues. Dawnscanner is able to scan plain ruby scripts (e.g. command line applications) but all its features are unleashed when dealing with web applications source code. It supports major MVC (Model View Controller) frameworks, out of the box: 

Website: https://dawnscanner.org/
Github: https://github.com/thesp0nge/dawnscanner
