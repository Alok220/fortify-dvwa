-Openscap-

The OpenSCAP ecosystem provides multiple tools to assist administrators and auditors with assessment, measurement, and enforcement of security baselines. We maintain great flexibility and interoperability, reducing the costs of performing security audits.

Website: https://www.open-scap.org/
Github: https://github.com/OpenSCAP/openscap`
