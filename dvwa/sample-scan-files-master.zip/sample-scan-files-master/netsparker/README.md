-Netsparker-

Netsparker is an easy to use and fully automated web application security scanner that uses the advanced Proof-Based ScanningTM technology to identify SQL Injection, Cross-site Scripting (XSS) and thousands of other vulnerabilities in web applications, web services and web APIs. The Netsparker web vulnerability scanner also has built-in security testing tools, reports generator, and can be easily integrated in your SDLC, DevOps and other environments.

Website: https://www.netsparker.com/web-vulnerability-scanner/
