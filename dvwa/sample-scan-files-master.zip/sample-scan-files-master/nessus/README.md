-Nessus-

Nessus was built from the ground-up with a deep understanding of how security practitioners work. Every feature in Nessus is designed to make vulnerability assessment simple, easy and intuitive. The result: less time and effort to assess, prioritize, and remediate issues. 

Website: https://www.tenable.com/products/nessus

Example files below come from Nessus Security Center v5.19.0

* sc_vulnerability_list_v00.csv 
* sc_vulnerability_summary_v00.csv
