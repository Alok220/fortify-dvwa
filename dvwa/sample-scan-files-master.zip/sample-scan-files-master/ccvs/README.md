-CCVS-

<b>Central Container Vulnerability Scanning</b>, A central API to scan containers images using different vendors. There are multiples tools to scan containers/images. But each one can show different results against the same target. So this project has the goal to use multiples tools and has a complete vision of vulnerabilities

Github: https://github.com/William-Hill-Online/CCVS-API