-Bundler Audit-

bundler-audit provides patch-level verification for Bundled apps.

Website: bundler-audit provides patch-level verification for Bundled apps.
Github: https://github.com/rubysec/bundler-audit
