-Gitleaks-

Gitleaks is a fast and customizable scanner to find secrets using regex and entropy in git repositories.

Github: https://github.com/zricethezav/gitleaks
