-Blackduck-

For over 15 years, security, development, and legal teams around the globe have relied on Black Duck to help them manage the risks that come with the use of open source.Built on the Black Duck KnowledgeBase™—the most comprehensive database of open source component, vulnerability, and license information—Black Duck software composition analysis solutions and open source audits give you the insight you need to track the open source in your code, mitigate security and license compliance risks, and automatically enforce open source policies using your existing DevOps tools and processes.

Website: https://www.blackducksoftware.com/
