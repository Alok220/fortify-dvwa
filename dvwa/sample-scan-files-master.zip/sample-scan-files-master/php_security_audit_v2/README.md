-Php security audit-

phpcs-security-audit is a set of PHP_CodeSniffer rules that finds vulnerabilities and weaknesses related to security in PHP code.

Github: https://github.com/FloeDesignTechnologies/phpcs-security-audit
