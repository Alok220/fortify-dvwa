-Defect Dojo-

This is a sample Defect Dojo instance that can be loaded via loaddata into an instance of a defectdojo server. 
